import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Scanner;

public class MLP_Main {
		
	//for annealing
	private double startLP = 0.1;
	private double endLP = 0.05;
	
	private int inputs = 8;
	private int hiddenNodes = 8;
	private int epochs = 5000;
	private double learningParameter = startLP;
	private boolean sigmoid = true;
	private double alpha = 0.9; //used for the momentum modification
	
	private ArrayList<Training_Node> inputNodesArray = new ArrayList<Training_Node>();
	private ArrayList<Training_Node> hiddenNodesArray = new ArrayList<Training_Node>();
	private ArrayList<Training_Node> outputNodeArray = new ArrayList<Training_Node>();
	
	/* for worked example
	double [] [] inputArray = 
		{ {1, 0, 1}};
	*/
	
	private ArrayList<Double> finalNodeOutputs = new ArrayList<Double>();
	private ArrayList<Double> correctOutputsList = new ArrayList<Double>();
	private ArrayList<Double> errors = new ArrayList<Double>();
	
	private ArrayList<String> arrayOfTrainingInputs = new ArrayList<String>();
	private ArrayList<String> arrayOfValidationInputs = new ArrayList<String>();
	private ArrayList<Double> maxOfInputs = new ArrayList<Double>();
	private ArrayList<Double> minOfInputs = new ArrayList<Double>();
	
	private String trainingDataFile = "trainingData.txt";
	private String validationDataFile = "testingData.txt";
	
	
	
	public static void main(String[] args) throws FileNotFoundException {
		
		MLP_Main mlp_main = new MLP_Main();
		
		/*WORKED EXAMPLE training
		mlp_main.initialiseAsWorkedExample();
		mlp_main.train();
		*/
		
		//REAL training
		mlp_main.initialiseNodes();
		mlp_main.initialiseWeights();
		mlp_main.initialiseInputs();
		mlp_main.train();
		mlp_main.validate();
		//System.out.print(mlp_main.getOutputNodeArray().get(0).getActivation());
		
		
		/* testing initialisation of nodes works correctly
		ArrayList<Training_Node> inputsArray = mlp_main.getInputNodesArray();
		ArrayList<Training_Node> hiddenArray = mlp_main.getHiddenNodesArray();
		ArrayList<Training_Node> outputArray = mlp_main.getOutputNodeArray();
		
		for(Training_Node n: inputsArray) {
			System.out.println(n.toString());
		}
		for(Training_Node n: hiddenArray) {
			System.out.println(n.toString());
		}
		for(Training_Node n: outputArray) {
			System.out.println(n.toString());
		}
		*/
	}

	//standardising to [0.1, 0.9]
	public static double standardise(double min, double max, double valueToStandardise) {
		double standardisedValue = ((0.8*((valueToStandardise-min)/(max-min)))+0.1);
		return standardisedValue;
	}
	
	//destandardising from [0.1, 0.9]
	public static double destandardise(double min, double max, double valueToDestandardise) {
		double destandardisedValue = ((((valueToDestandardise-0.1)/0.8)*(max-min))+min);
		return destandardisedValue;
	}
	
	//used to calculate the LP in simulated annealing
	public static double annealingLPCalcFunction(double startLP, double endLP, int maxEpochs, int epochsSoFar) {
		double newLP = endLP+(startLP-endLP)*(1-(1/(1+Math.exp(10-((20*epochsSoFar)/maxEpochs)))));
		return newLP;
	}
	
	
	public static double sigmoidFunction(double input) {
		double output = (1/(1+Math.exp(-input)));
		return output;
	}
	
	public static double sigmoidFirstDerivative(double input) {
		double firstTerm = MLP_Main.sigmoidFunction(input);
		double secondTerm = (1-firstTerm);
		double output = firstTerm*secondTerm;
		return output;
	}
	
	
	
	
	
	
	/*
	public void initialiseAsWorkedExample() {
		
		double [] [] inputArray = 
			{ {1, 0, 1}};
		
		//initialise input nodes

		//input 1 (u1)
		HashMap<Integer, Double> weightsToNode = new HashMap<Integer, Double>();
		HashMap<Integer, Double> weightsFromNode = new HashMap<Integer, Double>();
		weightsFromNode.put(0, (double) 3);
		weightsFromNode.put(1, (double) 6);
		double bias = 0;
		double weightedSum = inputArray[0][0];
		double activation = 0;
		double delta = 0;
		
		//added for momentum
		double previousBiasChange = 0;
		HashMap<Integer, Double> momentumForWeightsToNode = new HashMap<Integer, Double>();
		HashMap<Integer, Double> momentumForWeightsFromNode = new HashMap<Integer, Double>();
		momentumForWeightsFromNode.put(0, (double) 0);
		momentumForWeightsFromNode.put(1, (double) 0);
		
		Training_Node node = new Training_Node("Input", weightsToNode, weightsFromNode, bias, weightedSum, activation, delta, previousBiasChange, momentumForWeightsToNode, momentumForWeightsFromNode);
		
		inputNodesArray.add(node);
		
		//input 2 (u2)
		weightsToNode = new HashMap<Integer, Double>();
		weightsFromNode = new HashMap<Integer, Double>();
		weightsFromNode.put(0, (double) 4);
		weightsFromNode.put(1, (double) 5);
		bias = 0;
		weightedSum = inputArray[0][1];
		activation = 0;
		delta = 0;
		
		//added for momentum
		previousBiasChange = 0;
		momentumForWeightsToNode = new HashMap<Integer, Double>();
		momentumForWeightsFromNode = new HashMap<Integer, Double>();
		momentumForWeightsFromNode.put(0, (double) 0);
		momentumForWeightsFromNode.put(1, (double) 0);
		
		node = new Training_Node("Input", weightsToNode, weightsFromNode, bias, weightedSum, activation, delta, previousBiasChange, momentumForWeightsToNode, momentumForWeightsFromNode);
		
		inputNodesArray.add(node);	
		
		//initialise hidden nodes
			
		//hidden node 1 (u3)	
		weightsToNode = new HashMap<Integer, Double>();
		weightsToNode.put(0, (double) 3);
		weightsToNode.put(1, (double) 4);
		weightsFromNode = new HashMap<Integer, Double>();
		weightsFromNode.put(0, (double) 2);
		bias = 1;
		weightedSum = 0;
		activation = 0;
		delta = 0;
		
		//added for momentum
		previousBiasChange = 0;
		momentumForWeightsToNode = new HashMap<Integer, Double>();
		momentumForWeightsToNode.put(0, (double) 0);
		momentumForWeightsToNode.put(1, (double) 0);
		momentumForWeightsFromNode = new HashMap<Integer, Double>();
		momentumForWeightsFromNode.put(0, (double) 0);
		
		node = new Training_Node("Hidden", weightsToNode, weightsFromNode, bias, weightedSum, activation, delta, previousBiasChange, momentumForWeightsToNode, momentumForWeightsFromNode);
		
		hiddenNodesArray.add(node);
		
		//hidden node 2 (u4)	
		weightsToNode = new HashMap<Integer, Double>();
		weightsToNode.put(0, (double) 6);
		weightsToNode.put(1, (double) 5);
		weightsFromNode = new HashMap<Integer, Double>();
		weightsFromNode.put(0, (double) 4);
		bias = -6;
		weightedSum = 0;
		activation = 0;
		delta = 0;
		
		//added for momentum
		previousBiasChange = 0;
		momentumForWeightsToNode = new HashMap<Integer, Double>();
		momentumForWeightsToNode.put(0, (double) 0);
		momentumForWeightsToNode.put(1, (double) 0);
		momentumForWeightsFromNode = new HashMap<Integer, Double>();
		momentumForWeightsFromNode.put(0, (double) 0);
				
		node = new Training_Node("Hidden", weightsToNode, weightsFromNode, bias, weightedSum, activation, delta, previousBiasChange, momentumForWeightsToNode, momentumForWeightsFromNode);
				
		hiddenNodesArray.add(node);
		
		
		//initialise output node
				
		weightsToNode = new HashMap<Integer, Double>();
		weightsToNode.put(0, (double) 2);
		weightsToNode.put(1, (double) 4);
		weightsFromNode = new HashMap<Integer, Double>();
		bias = -3.92;
		weightedSum = 0;
		activation = 0;
		delta = 0;
		
		//added for momentum
		previousBiasChange = 0;
		momentumForWeightsToNode = new HashMap<Integer, Double>();
		momentumForWeightsToNode.put(0, (double) 0);
		momentumForWeightsToNode.put(1, (double) 0);
		momentumForWeightsFromNode = new HashMap<Integer, Double>();
			
		node = new Training_Node("Output", weightsToNode, weightsFromNode, bias, weightedSum, activation, delta, previousBiasChange, momentumForWeightsToNode, momentumForWeightsFromNode);
			
		outputNodeArray.add(node);
	}
	*/
	
	
	
	public void initialiseInputs() throws FileNotFoundException{
		
		// add the minimum values for each input for the training and validation data into the list
		this.minOfInputs.add(1.63);
		this.minOfInputs.add(0.196);
		this.minOfInputs.add(0.664);
		this.minOfInputs.add(0.0023);
		this.minOfInputs.add(2.21);
		this.minOfInputs.add(0.22);
		this.minOfInputs.add(10.1);
		this.minOfInputs.add(558.0);
		this.minOfInputs.add(0.406);
		
		// add the maximum values for each input for the training and validation data into the list
		this.maxOfInputs.add(4389.66);
		this.maxOfInputs.add(0.974);
		this.maxOfInputs.add(1.0);
		this.maxOfInputs.add(0.2498);
		this.maxOfInputs.add(244.21);
		this.maxOfInputs.add(0.85);
		this.maxOfInputs.add(81.9);
		this.maxOfInputs.add(2848.0);
		this.maxOfInputs.add(880.582);
		
		// populate the training data array
		File trainingDataFile = new File(this.trainingDataFile);
		Scanner fileScanner = new Scanner(trainingDataFile);
		
		while (fileScanner.hasNextLine()) {
			String line = fileScanner.nextLine();
			this.arrayOfTrainingInputs.add(line);
		}
		
		fileScanner.close();
		
		//populate the validation data array
		File validationDataFile = new File(this.validationDataFile);
		Scanner fileScanner2 = new Scanner(validationDataFile);
		
		while (fileScanner2.hasNextLine()) {
			String line = fileScanner2.nextLine();
			this.arrayOfValidationInputs.add(line);
		}
		
		fileScanner2.close();
	}
	
	
	public void initialiseNodes() {
		
		//initialises everything except starting weights.
		//input's weighted sum = input, others weighted sum = 0, activation = 0, delta = 0.
		
		//initialise input nodes

		for(int i = 0; i<inputs;i++) {
			
			HashMap<Integer, Double> weightsToNode = new HashMap<Integer, Double>();
			HashMap<Integer, Double> weightsFromNode = new HashMap<Integer, Double>();
			double bias = 0;
			double weightedSum = 0;
			double activation = 0;
			double delta = 0;
			
			//added for momentum
			double previousBiasChange = 0;
			HashMap<Integer, Double> momentumForWeightsToNode = new HashMap<Integer, Double>();
			HashMap<Integer, Double> momentumForWeightsFromNode = new HashMap<Integer, Double>();
			
			Training_Node node = new Training_Node("Input", weightsToNode, weightsFromNode, bias, weightedSum, activation, delta, previousBiasChange, momentumForWeightsToNode, momentumForWeightsFromNode);
			
			inputNodesArray.add(node);
		}
		
		//initialise hidden nodes
		
		for(int i = 0; i<hiddenNodes;i++) {
			
			HashMap<Integer, Double> weightsToNode = new HashMap<Integer, Double>();
			HashMap<Integer, Double> weightsFromNode = new HashMap<Integer, Double>();
			double bias = 0;
			double weightedSum = 0;
			double activation = 0;
			double delta = 0;
			
			//added for momentum
			double previousBiasChange = 0;
			HashMap<Integer, Double> momentumForWeightsToNode = new HashMap<Integer, Double>();
			HashMap<Integer, Double> momentumForWeightsFromNode = new HashMap<Integer, Double>();
				
			
			Training_Node node = new Training_Node("Hidden", weightsToNode, weightsFromNode, bias, weightedSum, activation, delta, previousBiasChange, momentumForWeightsToNode, momentumForWeightsFromNode);
			
			hiddenNodesArray.add(node);
		}
		
		//initialise output node
				
		HashMap<Integer, Double> weightsToNode = new HashMap<Integer, Double>();
		HashMap<Integer, Double> weightsFromNode = new HashMap<Integer, Double>();
		double bias = 0;
		double weightedSum = 0;
		double activation = 0;
		double delta = 0;
		
		//added for momentum
		double previousBiasChange = 0;
		HashMap<Integer, Double> momentumForWeightsToNode = new HashMap<Integer, Double>();
		HashMap<Integer, Double> momentumForWeightsFromNode = new HashMap<Integer, Double>();
			
		Training_Node node = new Training_Node("Output", weightsToNode, weightsFromNode, bias, weightedSum, activation, delta, previousBiasChange, momentumForWeightsToNode, momentumForWeightsFromNode);
			
		outputNodeArray.add(node);
	}
	
	
	
	
	
	//NEED TO INITIALISE THE MOMENTUM FOR WEIGHTS VALUES IN HASHMAP IN THIS METHOD NOT BIASES AS ALREADY DONE
	//THEN MAKE MOMENTUM UPDATE THE WEIGHTS AND MAKE MOMENTUM FOR WEIGHTS UPDATE AS WELL IN THE TRAIN METHOD
	public void initialiseWeights() {
		
		//Randomly generated weights and biases. Update both 'from'array and 'to' array for each weight.
		
		double minWeight = (-0.25);
		//TEST!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		//System.out.println(Double.toString(minWeight));
		double maxWeight = (0.25);
		
		//weights between input nodes and hidden nodes
		//no biases as they're the input nodes
		
		for(int i = 0; i<inputs;i++) {
			
			Random randomVal = new Random();
			
			for(int j =0; j<hiddenNodes;j++) {
				
				double weightVal = minWeight + (maxWeight-minWeight) * randomVal.nextDouble();
				
				//TEST!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
				//System.out.println(weightVal);
				
				inputNodesArray.get(i).setWeightsFromNode(j, weightVal);
				hiddenNodesArray.get(j).setWeightsToNode(i, weightVal);
				
				//for momentum
				inputNodesArray.get(i).setMomentumForWeightsFromNode(j, 0);
				hiddenNodesArray.get(j).setMomentumForWeightsToNode(i, 0);
				
			}
		}
		
		//weights between hidden nodes and output node
		
		for(int i = 0; i<hiddenNodes;i++) {
				
			Random randomVal = new Random();
			double biasVal = minWeight + (maxWeight-minWeight) * randomVal.nextDouble();
				
			hiddenNodesArray.get(i).setBias(biasVal);
			
			double weightVal = minWeight + (maxWeight-minWeight) * randomVal.nextDouble();
			hiddenNodesArray.get(i).setWeightsFromNode(0, weightVal);
			outputNodeArray.get(0).setWeightsToNode(i, weightVal);
			
			//for momentum
			hiddenNodesArray.get(i).setMomentumForWeightsFromNode(0, 0);
			outputNodeArray.get(0).setMomentumForWeightsToNode(i, 0);
					
		}	
		
		//set the bias for the output node
		
		Random randomVal = new Random();
		double biasVal = minWeight + (maxWeight-minWeight) * randomVal.nextDouble();
		outputNodeArray.get(0).setBias(biasVal);
		
	}
	
	
	
	
	
	
	
	public void train() {
		
		for (int i = 0; i<this.getEpochs(); i++) {
			
			//CHECK NUM INTPUTS WHEN USING REAL DATA; IRRELEVANT ATM AS ONLY 1 RECORD
			//in this bit need to set input nodes weighted sum = input for this record
			for (int k = 0; k<this.arrayOfTrainingInputs.size();k++) {
			
				ArrayList<Training_Node> inputsArray = this.getInputNodesArray();
				ArrayList<Training_Node> hiddenArray = this.getHiddenNodesArray();
				ArrayList<Training_Node> outputArray = this.getOutputNodeArray();
				
				//initialise inputs for this pass
				String splitRecord [] = this.getArrayOfTrainingInputs().get(k).split("\t");
				for(int j=0; j<inputsArray.size(); j++) {
					Training_Node currentNode = inputsArray.get(j);
					String stringValue = splitRecord[j];
					double doubleValue = Double.parseDouble(stringValue);
					
					//standardise the input
					double minimum = this.minOfInputs.get(j);
					double maximum = this.maxOfInputs.get(j);					
					double standardisedValue = MLP_Main.standardise(minimum, maximum, doubleValue);
					currentNode.setWeightedSum(standardisedValue);
				}
				
				//now inputs are initialised
				
				//FORWARD PASS
				
				//calculate weighted sums and activations for the hidden layer nodes
				
				/*obsolete
				//get this training example E
				
				ArrayList<Double> inputValues = new ArrayList<Double>();
				for (Training_Node n: inputsArray) {
					inputValues.add(n.getWeightedSum());
				}
				*/
				
				//iterate through hidden nodes, calculating weighted sum and activation for each
				
				for(int j=0; j<hiddenArray.size(); j++) {
					
					//sum of input*weight for each input node +bias for each hidden node
					//get node, get input node weights, get inputs
					
					Training_Node currentNode = hiddenArray.get(j);
					
					double weightedSum = 0;
					
					for (HashMap.Entry<Integer, Double> entry: currentNode.getWeightsToNode().entrySet()) {
						//entry.getKey gets the index of the node we want from the inputsArray
						double inputVal = inputsArray.get(entry.getKey()).getWeightedSum();																							
						double weightVal = entry.getValue();
						weightedSum = weightedSum+(inputVal*weightVal);
						
						
						
						//testing!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
						//System.out.println(weightedSum);
						//Scanner scanner = new Scanner(System.in);
						//String inputString = scanner.nextLine();
					}
					
					//add on the bias
					weightedSum = weightedSum+currentNode.getBias();
					
					currentNode.setWeightedSum(weightedSum);
					
					double sigmoided = MLP_Main.sigmoidFunction(weightedSum);
					
					currentNode.setActivation(sigmoided);
				}
				
				//calculate weighted sum and activation for output node
				
				for(int j = 0; j<outputArray.size(); j++) {
					
					Training_Node currentNode = outputArray.get(j);
					
					double weightedSum = 0;
					
					for (HashMap.Entry<Integer, Double> entry: currentNode.getWeightsToNode().entrySet()) {
						//testing!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
						//System.out.println(currentNode.getWeightsToNode()+"\n");
						//Scanner scanner = new Scanner(System.in);
						//String inputString = scanner.nextLine();
						//
						//entry.getKey gets the index of the node we want from the hiddenArray
						double inputVal = hiddenArray.get(entry.getKey()).getActivation();
						double weightVal = entry.getValue();
						weightedSum = weightedSum+(inputVal*weightVal);
					}
					
					//add on the bias
					weightedSum = weightedSum+currentNode.getBias();
					
					currentNode.setWeightedSum(weightedSum);
					
					double sigmoided = MLP_Main.sigmoidFunction(weightedSum);
					
					currentNode.setActivation(sigmoided);
					
					
					
					
					
					
					
					
					
					
					
					//testing!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
					//System.out.println(sigmoided+"\n");
					//Scanner scanner = new Scanner(System.in);
					//String inputString = scanner.nextLine();
				
				}
				
				//COMPARE OUTPUT
				//NEEDS TO CHANGE WITH REAL DATA
				
				double correctOutputNotStandardised= Double.parseDouble(splitRecord[this.getInputs()]);
				double correctOutput = MLP_Main.standardise(this.minOfInputs.get(this.getInputs()), this.maxOfInputs.get(this.getInputs()), correctOutputNotStandardised);
				
				//BACKWARD PASS
				
				//output node
				for(int j = 0; j<outputArray.size(); j++) {
					Training_Node currentNode = outputArray.get(j);
					currentNode.setDelta((correctOutput-currentNode.getActivation())*MLP_Main.sigmoidFirstDerivative(currentNode.getWeightedSum()));
				}
				
				//hidden nodes
				for(int j=0; j<hiddenArray.size(); j++) {
					
					Training_Node currentNode = hiddenArray.get(j);
					
					double outputDelta = outputArray.get(0).getDelta();
					double weightVal = currentNode.getWeightsFromNode().get(0);
					
					currentNode.setDelta(weightVal*outputDelta*MLP_Main.sigmoidFirstDerivative(currentNode.getWeightedSum()));
					
				}
				
				//Ui is always 1 for a bias
				//Ui is the input for input weights
				//Ui is the activation of hidden node when between output node
				
				// UPDATE WEIGHTS
				
				//weights between input nodes and hidden nodes
				//update each weight from input node and each weight to hidden node
				// no biases updated in this block as inputs don't have biases
				for (int j=0; j<inputsArray.size(); j++) {
					Training_Node currentNode = inputsArray.get(j);
					double Ui = currentNode.getWeightedSum();
					
					//iterates through the weights from this input node (to the hidden nodes)
					//need to get the current weight, the input value (Ui, above), the hidden node's activation
					for (HashMap.Entry<Integer, Double> entry: currentNode.getWeightsFromNode().entrySet()) {
						
						//get momentum parameter for this weight
						double momentumParameter = currentNode.getMomentumForWeightsFromNode().get(entry.getKey());
						
						//entry.getKey gets the index of the node we want from the hiddenArray
						double deltaj = hiddenArray.get(entry.getKey()).getDelta();
						//gets the value of the weight
						double weightVal = entry.getValue();
						double newWeight = weightVal+this.getLearningParameter()*deltaj*Ui+this.getAlpha()*momentumParameter;
						//sets the weight from the input layer to the new value
						entry.setValue(newWeight);
						//gets the node the weight goes to and updates the value of the weight there too
						hiddenArray.get(entry.getKey()).setWeightsToNode(j, newWeight);
						
						//get new momentum parameter for this weight
						double newMomentumParameter = newWeight-weightVal;
						
						//update the values stored for this momentum parameter
						hiddenArray.get(entry.getKey()).setMomentumForWeightsToNode(j, newMomentumParameter);
						currentNode.setMomentumForWeightsFromNode(entry.getKey(), newMomentumParameter);
					}
				}
				
				//weights between hidden and output node
				for (int j=0; j<hiddenArray.size(); j++) {
					Training_Node currentNode = hiddenArray.get(j);
					double Ui = currentNode.getActivation();
				
					//update bias for this hidden node
					double deltaj = currentNode.getDelta();
					double oldBias = currentNode.getBias();
					currentNode.setBias(currentNode.getBias()+this.getLearningParameter()*deltaj*1+this.getAlpha()*currentNode.getPreviousBiasChange());
					//update change in bias for momentum
					double newBiasChange = currentNode.getBias() - oldBias;
					currentNode.setPreviousBiasChange(newBiasChange);
					
					//iterates through weights from this hidden node to the output nodes
					for (HashMap.Entry<Integer, Double> entry: currentNode.getWeightsFromNode().entrySet()) {
						
						//get momentum parameter for this weight
						double momentumParameter = currentNode.getMomentumForWeightsFromNode().get(entry.getKey());
						
						//entry.getKey gets the index of the node we want from the outputArray
						deltaj = outputArray.get(entry.getKey()).getDelta();
						//gets the value of the weight
						double weightVal = entry.getValue();
						double newWeight = weightVal+this.getLearningParameter()*deltaj*Ui+this.getAlpha()*momentumParameter;
						//sets the weight from the hidden layer to the new value
						entry.setValue(newWeight);
						//gets the node the weight goes to and updates the value of the weight there too
						outputArray.get(entry.getKey()).setWeightsToNode(j, newWeight);
						
						//get new momentum parameter for this weight
						double newMomentumParameter = newWeight-weightVal;
						
						//update the values stored for this momentum parameter
						outputArray.get(entry.getKey()).setMomentumForWeightsToNode(j, newMomentumParameter);
						currentNode.setMomentumForWeightsFromNode(entry.getKey(), newMomentumParameter);
					}
				}
				
				
				//update bias of output node
				//need current bias and delta of output node
				Training_Node outputNode = outputArray.get(0);
				double deltaO = outputNode.getDelta();
				double oldBias = outputNode.getBias();
				outputNode.setBias(outputNode.getBias()+this.getLearningParameter()*deltaO*1+this.getAlpha()*outputNode.getPreviousBiasChange());
				
				//update change in output node's bias for momentum
				double newBiasChange = outputNode.getBias() - oldBias;
				outputNode.setPreviousBiasChange(newBiasChange);
				
				/*testing
				for(Training_Node n: inputsArray) {
					System.out.println(n.getWeightedSum());
				}
				Scanner scanner = new Scanner(System.in);
				String inputString = scanner.nextLine();
				*/
			
			}
			
			//annealing modification - update LP
			
			/*for testing
			System.out.println(this.getLearningParameter());
			*/
			
			int epochsThusFar = i+1;
			double newLearningParameter = MLP_Main.annealingLPCalcFunction(this.getStartLP(), this.getEndLP(), this.getEpochs(), epochsThusFar);
			this.setLearningParameter(newLearningParameter);
			
			
			/* for testing
			for(Training_Node n: inputsArray) {
				System.out.println(n.toString());
			}
			for(Training_Node n: hiddenArray) {
				System.out.println(n.toString());
			}
			for(Training_Node n: outputArray) {
				System.out.println(n.toString());
			}
			
			Scanner scanner = new Scanner(System.in);
			String inputString = scanner.nextLine();
			*/
		}
		
		/* for testing
		for(Training_Node n: inputNodesArray) {
			System.out.println(n.toString());
		}
		for(Training_Node n: hiddenNodesArray) {
			System.out.println(n.toString());
		}
		for(Training_Node n: outputNodeArray) {
			System.out.println(n.toString());
		}
		*/
	}
	
	
	
	
	
	
	
	public void validate() {
		for (int k = 0; k<this.arrayOfValidationInputs.size();k++) {
			
			ArrayList<Training_Node> inputsArray = this.getInputNodesArray();
			ArrayList<Training_Node> hiddenArray = this.getHiddenNodesArray();
			ArrayList<Training_Node> outputArray = this.getOutputNodeArray();
			
			//initialise inputs for this pass
			String splitRecord [] = this.getArrayOfValidationInputs().get(k).split("\t");
			for(int j=0; j<inputsArray.size(); j++) {
				Training_Node currentNode = inputsArray.get(j);
				String stringValue = splitRecord[j];
				double doubleValue = Double.parseDouble(stringValue);
				//standardise the input
				double minimum = this.minOfInputs.get(j);
				double maximum = this.maxOfInputs.get(j);
				double standardisedValue = MLP_Main.standardise(minimum, maximum, doubleValue);
				currentNode.setWeightedSum(standardisedValue);
			}
			
			//iterate through hidden nodes, calculating weighted sum and activation for each
			
			for(int j=0; j<hiddenArray.size(); j++) {
				
				//sum of input*weight for each input node +bias for each hidden node
				//get node, get input node weights, get inputs
				
				Training_Node currentNode = hiddenArray.get(j);
				
				double weightedSum = 0;
				
				for (HashMap.Entry<Integer, Double> entry: currentNode.getWeightsToNode().entrySet()) {
					//entry.getKey gets the index of the node we want from the inputsArray
					double inputVal = inputsArray.get(entry.getKey()).getWeightedSum();
					double weightVal = entry.getValue();
					weightedSum = weightedSum+(inputVal*weightVal);
				}
				
				//add on the bias
				weightedSum = weightedSum+currentNode.getBias();
				
				currentNode.setWeightedSum(weightedSum);
				
				double sigmoided = MLP_Main.sigmoidFunction(weightedSum);
				
				currentNode.setActivation(sigmoided);
			}
			
			//calculate weighted sum and activation for output node
			
			for(int j = 0; j<outputArray.size(); j++) {
				
				Training_Node currentNode = outputArray.get(j);
				
				double weightedSum = 0;
				
				for (HashMap.Entry<Integer, Double> entry: currentNode.getWeightsToNode().entrySet()) {
					//entry.getKey gets the index of the node we want from the hiddenArray
					double inputVal = hiddenArray.get(entry.getKey()).getActivation();
					double weightVal = entry.getValue();
					weightedSum = weightedSum+(inputVal*weightVal);
				}
				
				//add on the bias
				weightedSum = weightedSum+currentNode.getBias();
				
				currentNode.setWeightedSum(weightedSum);
				
				double sigmoided = MLP_Main.sigmoidFunction(weightedSum);
				
				currentNode.setActivation(sigmoided);
			
			}
			
			//COMPARE OUTPUT
			//NEEDS TO CHANGE WITH REAL DATA
			
			double correctOutput= Double.parseDouble(splitRecord[this.getInputs()]);
			this.correctOutputsList.add(correctOutput);
			double standardisedModelledOutput = outputArray.get(0).getActivation();
			
			double modelledOutput = MLP_Main.destandardise(this.minOfInputs.get(this.getInputs()), this.maxOfInputs.get(this.getInputs()), standardisedModelledOutput);
			this.finalNodeOutputs.add(modelledOutput);
			this.errors.add(Math.pow((modelledOutput-correctOutput), 2));
		}
		//calc RMSE
		double RMSE = 0;
		for (int q = 0; q<this.errors.size(); q++) {
			RMSE = RMSE+this.errors.get(q);
		}
		double MSE = RMSE/this.errors.size();
		RMSE = Math.sqrt(MSE);
		
		double meanOfCorrectOutputs = 0;
		for (int q = 0; q<this.correctOutputsList.size();q++) {
			meanOfCorrectOutputs = meanOfCorrectOutputs+correctOutputsList.get(q);
		}
		meanOfCorrectOutputs = meanOfCorrectOutputs/this.correctOutputsList.size();
		
		double sumDifMean = 0;
		for (int q = 0; q<this.correctOutputsList.size();q++) {
			sumDifMean = sumDifMean+Math.pow((correctOutputsList.get(q)-meanOfCorrectOutputs), 2);
		}
		
		double CE = (1-(MSE/sumDifMean));
		System.out.println("RMSE: "+RMSE);
		System.out.println("CE: "+CE);
		
		System.out.println("\nObserved Outputs:");
		for (int q=0; q<this.correctOutputsList.size();q++) {
			System.out.println(this.correctOutputsList.get(q));
		}
		System.out.println("\nModelled Outputs:");
		for (int q=0; q<this.finalNodeOutputs.size();q++) {
			System.out.println(this.finalNodeOutputs.get(q));
		}
	}
	
	
	
	
	
	
	

	public int getInputs() {
		return inputs;
	}

	public int getHiddenNodes() {
		return hiddenNodes;
	}

	public int getEpochs() {
		return epochs;
	}

	public boolean getSigmoid() {
		return sigmoid;
	}

	public double getLearningParameter() {
		return learningParameter;
	}
	
	public void setLearningParameter(double newLearningParameter) {
		this.learningParameter = newLearningParameter;
	}

	public ArrayList<Training_Node> getInputNodesArray() {
		return inputNodesArray;
	}

	public ArrayList<Training_Node> getHiddenNodesArray() {
		return hiddenNodesArray;
	}

	public ArrayList<Training_Node> getOutputNodeArray() {
		return outputNodeArray;
	}

	public double getAlpha() {
		return alpha;
	}
	
	public double getStartLP() {
		return startLP;
	}
	
	public double getEndLP() {
		return endLP;
	}

	public ArrayList<Double> getFinalNodeOutputs() {
		return finalNodeOutputs;
	}

	public void setFinalNodeOutputs(ArrayList<Double> finalNodeOutputs) {
		this.finalNodeOutputs = finalNodeOutputs;
	}

	public ArrayList<Double> getErrors() {
		return errors;
	}

	public void setErrors(ArrayList<Double> errors) {
		this.errors = errors;
	}

	public ArrayList<String> getArrayOfTrainingInputs() {
		return arrayOfTrainingInputs;
	}

	public void setArrayOfTrainingInputs(ArrayList<String> arrayOfTrainingInputs) {
		this.arrayOfTrainingInputs = arrayOfTrainingInputs;
	}

	public ArrayList<String> getArrayOfValidationInputs() {
		return arrayOfValidationInputs;
	}

	public void setArrayOfValidationInputs(ArrayList<String> arrayOfValidationInputs) {
		this.arrayOfValidationInputs = arrayOfValidationInputs;
	}
}
