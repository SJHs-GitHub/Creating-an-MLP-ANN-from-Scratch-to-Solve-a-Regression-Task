import java.util.HashMap;

public class Training_Node {
	
	private String type;
	private HashMap<Integer, Double> weightsToNode;
	private HashMap<Integer, Double> weightsFromNode;
	private double bias;
	private double weightedSum;
	private double activation;
	private double delta;
	
	//added for momentum
	private double previousBiasChange;
	private HashMap<Integer, Double> momentumForWeightsToNode;
	private HashMap<Integer, Double> momentumForWeightsFromNode;
	
	
	public Training_Node(String type, HashMap<Integer, Double> weightsToNode, HashMap<Integer, Double> weightsFromNode, double bias, double weightedSum, double activation, double delta, double previousBiasChange, HashMap<Integer, Double> momentumForWeightsToNode,HashMap<Integer, Double> momentumForWeightsFromNode) {
		
		this.type = type;
		this.weightsToNode = weightsToNode;
		this.weightsFromNode = weightsFromNode;
		this.bias = bias;
		this.weightedSum = weightedSum;
		this.activation = activation;
		this.delta = delta;
		
		//added for momentum
		this.previousBiasChange = previousBiasChange;
		this.momentumForWeightsToNode = momentumForWeightsToNode;
		this.momentumForWeightsFromNode = momentumForWeightsFromNode;
		
	}
	
	public String getType() {
		return type;
	}
		
	public double getDelta() {
		return delta;
	}
	
	public void setDelta(double delta) {
		this.delta = delta;
	}
		
	public double getActivation() {
		return activation;
	}
	
	public void setActivation(double activation) {
		this.activation = activation;
	}
		
	public double getWeightedSum() {
		return weightedSum;
	}	
	
	public void setWeightedSum(double weightedSum) {
		this.weightedSum = weightedSum;
	}
		
	public double getBias() {
		return bias;
	}	
	
	public void setBias(double bias) {
		this.bias = bias;
	}	
	
	public HashMap<Integer, Double> getWeightsFromNode() {
		return weightsFromNode;
	}	
	
	public void setWeightsFromNode(int index, double weight) {
		this.weightsFromNode.put(index, weight);
	}	
	
	public HashMap<Integer, Double> getWeightsToNode() {
		return weightsToNode;
	}
	
	public void setWeightsToNode(int index, double weight) {
		this.weightsToNode.put(index, weight);
	}
	
	public String toString() {
		return (this.getType()+"\n"+this.getWeightsToNode()+"\n"+this.getWeightsFromNode()+"\n"+this.getBias()+"\n"+this.getWeightedSum()+"\n"+this.getActivation()+"\n"+this.getDelta()+"\n\n\n");		
	}

	public double getPreviousBiasChange() {
		return previousBiasChange;
	}

	public void setPreviousBiasChange(double previousBiasChange) {
		this.previousBiasChange = previousBiasChange;
	}

	public HashMap<Integer, Double> getMomentumForWeightsToNode() {
		return momentumForWeightsToNode;
	}

	public void setMomentumForWeightsToNode(int index, double weight) {
		this.momentumForWeightsToNode.put(index, weight);
	}

	public HashMap<Integer, Double> getMomentumForWeightsFromNode() {
		return momentumForWeightsFromNode;
	}

	public void setMomentumForWeightsFromNode(int index, double weight) {
		this.momentumForWeightsFromNode.put(index, weight);
	}
}
